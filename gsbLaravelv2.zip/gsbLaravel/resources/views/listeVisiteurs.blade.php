@extends ('sommaireAdmin')
    @section('contenu1')
      <div id="contenu">
        <h2>Mes fiches de frais</h2>
        <h3>Visiteurs : </h3>
      <form action="{{ route('chemin_listerVisiteurs') }}" method="get">
        {{ csrf_field() }} <!-- laravel va ajouter un champ caché avec un token -->
        <div class="corpsForm"><p>

          <label for="lstVisiteurs" accesskey="n">Visiteurs : </label>
          <select id="lstVisiteurs" name="lstVisiteurs">
              @foreach($lesVisiteurs as $unVisiteur)
              <option type="text" value="<?php echo $unVisiteur['id']; ?>"><?php echo $unVisiteur['id'] ?></option>
              @endforeach
          </select>
        </p>
        </div>
          <input id="ok" type="submit" value="Valider" size="20" />
          <input id="annuler" type="reset" value="Effacer" size="20" />
        </form>
  @endsection 
