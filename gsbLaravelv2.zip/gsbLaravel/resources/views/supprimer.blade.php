@extends ('listeVisiteurs')
    @section('contenu2')
        <label for="id">Liste des membres : </label>
        <select id="id" name="id">
              @foreach($lesVisiteurs  as $unVisiteur)
              <option type="text" value="<?php echo $unVisiteur['id']; ?>">
                <?php echo $unVisiteur['id'] ?>
                <?php echo $unVisiteur['prenom'] ?>
                <?php echo $unVisiteur['nom'] ?></option>
              @endforeach
              </select>
            <input type="submit" value="valider">
            <input type="submit" value="annuler">
  @endsection 
 