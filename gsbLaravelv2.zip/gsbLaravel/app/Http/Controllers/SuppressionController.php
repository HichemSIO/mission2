<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use PdoGsb;
use MyDate;
class SuppressionController extends Controller
{
    function voirEtatVisiteur(){

		//$idVisiteur = $_REQUEST['lstVisiteurs']; 
        $admin = session('admin');
		$lesVisiteurs=PdoGsb::getLesVisiteurs();
		// Afin de sélectionner par défaut le dernier mois dans la zone de liste
		// on demande toutes les clés, et on prend la première,
		// les mois étant triés décroissants
		$lesCles = array_keys( $lesVisiteurs );
		$visiteursASelectionner = $lesCles[0];
        $vue = view('supprimer')->with('lesVisiteurs', $lesVisiteurs)
                    ->with('admin',$admin);
            return $vue;
        
    }

    function archivage(){
        if (isset($_POST['id']))
            {
            //le formulaire est complet
            //On recupère les données en les protégeant 
            $_id = strip_tags($_POST['id']);
            }
            @$_id = $_POST['id'];
            $rep=PdoGsb::insertArchivageVisiteur($_id);
            $rep2=PdoGsb::insertArchivageFrais($_id);
        
        if ($rep!= true && $rep2!= true)
    {echo'Echoué!';}
    else{
        $message="Archivage reussi !";
    }
    }

    function controledelete(){
            if (isset($_POST['id']))
            {
            //le formulaire est complet
            //On recupère les données en les protégeant 
            $_id = strip_tags($_POST['id']);
            }
        @$_id = $_POST['id'];

        $rep2=PdoGsb::deleteFrais($_id);
        $rep=PdoGsb::deleteVisiteur($_id);
        

        if ($rep!= true && $rep2!= true)
    {$message=$rep;}
    else{
        $message="Membre supprimé ";
    }

    return view('supprimer');
    
    }


    
}