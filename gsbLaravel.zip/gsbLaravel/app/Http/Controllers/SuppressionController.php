<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use PdoGsb;
use MyDate;
class SuppressionController extends Controller
{
    function voirEtatVisiteur(){

		$idVisiteur = $_REQUEST['lstVisiteurs']; 

		$lesVisiteurs=$pdo->getLesVisiteurs();
		include("views/v_fraisvisiteur.php");
		//$moisASelectionner = $leMois;
		
		$lesInfos=$pdo->getLesVisiteurs($idVisiteur);
	
	
		include("views/v_etatVisiteur.php");
	
    }

    
    
}