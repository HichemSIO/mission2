@extends ('modeles/visiteur')
    @section('menu')
            <!-- Division pour le sommaire -->
        <div id="menuGauche">
            <div id="infosUtil">
                  
             </div>  
               <ul id="menuList">
                   <li >
                    <strong>Bonjour {{ $admin['nom'] . ' ' . $admin['prenom'] }}</strong>
                      
                   </li>
             
                  <li class="smenu">
                    <a href="{{ route('chemin_ajoutVisiteur') }}" title="Ajouter un Visiteur">Ajouter un Visiteur</a>
                  </li>
                  <li class="smenu">
                    <a href="{{ route('chemin_genererEtat') }}" title="Génerer un état">Génerer un état</a>
                  </li>
                  <li class="smenu">
                    <a href="{{ route('chemin_gererVisiteurs') }}" title="Gérer les Visiteurs">Gérer les Visiteurs</a>
                  </li>
               <li class="smenu">
                <a href="{{ route('chemin_deconnexion') }}" title="Se déconnecter">Déconnexion</a>
                  </li>
                </ul>
               
        </div>
    @endsection          